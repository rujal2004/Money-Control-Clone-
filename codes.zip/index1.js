
function log()
{
var email =document.getElementById("user").value;
var pass =document.getElementById("password").value;
if(email==='rujalgupta656@gmail.com'&& pass==='123')
{
    alert("success full");
    window.location.assign("des.html");
}
else{
    alert("wrong entry")
}

}

